export default {
    name: "HeaderPost",
    template: `
        <header>
            <h1>NEWSPAPER</h1>
            <nav>
                <ul>
                    <a href="">Principal</a>
                    <a href=""> Posts </a>
                    <a href=""> Author </a>
                    <a href=""> About us</a>
                    <a href="">Contact</a>
                    
                </ul>
            </nav>
        </header>`
};
